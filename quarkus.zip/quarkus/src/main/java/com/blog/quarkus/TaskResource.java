package com.blog.quarkus;


import java.util.*;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;

@Path("/tasks")
public class TaskResource {

    private Map<Integer, String> tasks = new HashMap<>();
    private int currentId = 1;

    @GET
    @Produces("application/json")
    public Collection<String> getAllTasks() {
        return tasks.values();
    }

    @POST
    @Consumes("application/json")
    public Response createTask(String task) {
        tasks.put(currentId++, task);
        return Response.status(Response.Status.CREATED).build();
    }

    @GET
    @Path("/{id}")
    @Produces("application/json")
    public Response getTask(@PathParam("id") int id) {
        String task = tasks.get(id);
        if (task == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.ok(task).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes("application/json")
    public Response updateTask(@PathParam("id") int id, String updatedTask) {
        if (!tasks.containsKey(id)) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        tasks.put(id, updatedTask);
        return Response.ok().build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteTask(@PathParam("id") int id) {
        if (tasks.remove(id) == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.noContent().build();
    }
}
